<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:61:"/usr/local/www/shop/public/../app/admin/view/Brand/index.html";i:1496074021;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>SHOP 管理中心 - 品牌管理 </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="__STATIC__/admin/css/general.css" rel="stylesheet" type="text/css" />
<link href="__STATIC__/admin/css/main.css" rel="stylesheet" type="text/css" />
</head>
<body>

<h1>
<span class="action-span"><a href="<?php echo Url('Brand/add'); ?>">添加品牌</a></span>
<span class="action-span1"><a href="index.php?act=main">SHOP 管理中心</a> </span><span id="search_id" class="action-span1"> - 商品品牌 </span>
<div style="clear:both"></div>
</h1>

<div class="form-div">
  <form action="javascript:search_brand()" name="searchForm">
    <img src="__STATIC__/admin/images/icon_search.gif" width="26" height="22" border="0" alt="SEARCH">
     <input type="text" name="brand_name" size="15">
    <input type="submit" value=" 搜索 " class="button">
  </form>
</div>

<form method="post" action="" name="listForm">
<!-- start brand list -->
<div class="list-div" id="listDiv">

  <table cellpadding="3" cellspacing="1">
    <tbody>
		<tr>
			<th>品牌名称</th>
			<th>品牌网址</th>
			<th>品牌描述</th>
			<th>排序</th>
			<th>是否显示</th>
			<th>操作</th>
		</tr>
	 <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): if( count($list)==0 ) : echo "" ;else: foreach($list as $key=>$vo): ?>
        <tr>
			<td class="first-cell"><span style="float:right"><a href="../data/brandlogo/1240803062307572427.gif" target="_brank"><img src="__STATIC__/admin/images/picflag.gif" width="16" height="16" border="0" alt="品牌LOGO"></a></span>
			<span onclick="javascript:listTable.edit(this, 'edit_brand_name', 1)" title="点击修改内容" style=""><?php echo $vo['brand_name']; ?></span>
			</td>
			<td><a href="http://<?php echo $vo['url']; ?>" target="_brank"></a><?php echo $vo['url']; ?></td>
			<td align="left" ><?php echo $vo['brand_desc']; ?></td>
			<td align="right"><span onclick="javascript:listTable.edit(this, 'edit_sort_order', 1)"><?php echo $vo['sort_order']; ?></span></td>
			<td align="center"><img src='__STATIC__/admin/images/<?php echo !empty($vo['is_show']) && $vo['is_show']==1?'yes':'no'; ?>.gif' ></td>
			<td align="center">
				<a href="edit/id/<?php echo $vo['brand_id']; ?>" title="编辑">编辑</a> |
				<a href="<?php echo Url('Brand/delete','id='.$vo['brand_id']); ?>" onclick="return confirm ('你确认要删除选定的商品品牌吗？')" title="编辑">移除</a> 
			</td>
		</tr>
	<?php endforeach; endif; else: echo "" ;endif; ?>	
    <tr>
		<td align="right" nowrap="true" colspan="6">
            <div id="turn-page">
            
            <!--
			总计  <span id="totalRecords">11</span>
        个记录分为 <span id="totalPages">2</span>
        页当前第 <span id="pageCurrent">1</span>
        页，每页 <input type="text" size="3" id="pageSize" value="10" onkeypress="return listTable.changePageSize(event)">
        <span id="page-link">
          <a href="javascript:listTable.gotoPageFirst()">第一页</a>
          <a href="javascript:listTable.gotoPagePrev()">上一页</a>
          <a href="javascript:listTable.gotoPageNext()">下一页</a>
          <a href="javascript:listTable.gotoPageLast()">最末页</a>
          <select id="gotoPage" onchange="listTable.gotoPage(this.value)">
            <option value="1">1</option><option value="2">2</option>          </select>
        </span>
        -->
      </div>
      </td>
    </tr>
  </tbody></table>

<!-- end brand list -->
</div>
</form>


<div id="footer">
	版权所有 &copy; 2012-2013 传智播客 - PHP培训 - </div>
</div>

</body>
</html>
