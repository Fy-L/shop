<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:61:"/usr/local/www/shop/public/../app/index/view/Index/index.html";i:1495978617;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>1111111</title>
</head>
<body>
	
</body>
</html>

