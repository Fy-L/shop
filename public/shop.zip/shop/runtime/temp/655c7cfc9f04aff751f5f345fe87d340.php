<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:60:"/usr/local/www/shop/public/../app/admin/view/Index/main.html";i:1495998327;}*/ ?>
<!-- $Id: start.htm 17216 2011-01-19 06:03:12Z liubo $ -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>SHOP 管理中心</title>
<meta name="robots" content="noindex, nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="__STATIC__/admin/css/general.css" rel="stylesheet" type="text/css" />
<link href="__STATIC__/admin/css/main.css" rel="stylesheet" type="text/css" />
</head>
<body>

<h1>
<span class="action-span1"><a href="index.php?act=main">SHOP 管理中心</a> </span><span id="search_id" class="action-span1"></span>
<div style="clear:both"></div>
</h1>
<!-- directory install start -->
<ul id="cloud_list" style="padding:0; margin: 0; list-style-type:none; color: #CC0000;">

</ul>

<ul style="padding:0; margin: 0; list-style-type:none; color: #CC0000;">
</ul>
<div class="list-div">

</div>

<div id="footer">

</div>

</div>

</body>
</html>
