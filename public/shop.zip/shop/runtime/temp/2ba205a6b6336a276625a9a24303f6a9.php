<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:58:"/usr/local/www/shop/public/../app/admin/view/Type/add.html";i:1496152749;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>SHOP 管理中心 - 类型管理 </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="__STATIC__/admin/css/general.css" rel="stylesheet" type="text/css" />
<link href="__STATIC__/admin/css/main.css" rel="stylesheet" type="text/css" />
</head>
<body>

<h1>
<span class="action-span"><a href="<?php echo Url('Type/index'); ?>">商品类型列表</a></span>
<span class="action-span1"><a href="index.php?act=main">SHOP 管理中心</a> </span><span id="search_id" class="action-span1"> - 新建商品类型 </span>
<div style="clear:both"></div>
</h1>

<div class="main-div">
  <form action="" method="post" name="theForm" onsubmit="return validate();">
    <table cellspacing="1" cellpadding="3" width="100%">
      <tbody><tr>
        <td class="label">商品类型名称:</td>
        <td><input type="text" name="type_name" value="" size="40">
        <span class="require-field">*</span></td>
      </tr>    
      
      <tr align="center">
        <td colspan="2">         
          <input type="submit" value=" 确定 " class="button">
          <input type="reset" value=" 重置 " class="button">         
        </td>
      </tr>
    </tbody></table>
  </form>
</div>

<div id="footer">
	
</div>

</body>
</html>
