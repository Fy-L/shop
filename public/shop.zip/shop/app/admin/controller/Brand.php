<?php
namespace app\admin\controller;
use think\Request;
use think\Db;

class Brand extends Base
{
	public function index(){
		//获取数据
		$list = Db::table('shop_brand')->select();
		//dump($list);
		$this->assign('list',$list);
		return $this->fetch('Brand/index');
	}
	public function add(){
		$request = Request::instance();
		if($request->isPost()){
			$data = $request->Post();
			//dump($data);
			$re = Db::table('shop_brand')->insert($data);
			if($re){
				$this->success('添加成功','Brand/index');
			}else{
				$this->error('添加失败');
			}
		}else{
			return $this->fetch('Brand/add');
		}
	}
	public function edit(){
		$request = Request::instance();
		if($request->isPost()){
			$data = array(
				'brand_id'=> $request->post('id'),
				'url'=>$request->post('url'),
				'brand_desc'=>$request->post('brand_desc'),
				'sort_order'=>$request->post('sort_order'),
				'is_show'=>$request->post('is_show'),
				'brand_name'=>$request->post('brand_name'),
				);			
			$re = Db::table('shop_brand')->update($data);
			if(false !== $re){
				$this->success('修改成功','Brand/index');
			}else{
				$this->error('修改失败');
			}
		}
		$id = input('id');
		//dump($id);		
		$find = Db::table('shop_brand')->where('brand_id',$id)->find();
		if(!$find){
			$this->error('没有数据','Brand/index');
		}
		$this->assign('det',$find);
		return $this->fetch('Brand/edit');
	}
}
