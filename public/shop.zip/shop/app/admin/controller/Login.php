<?php
namespace app\admin\controller;
use think\Request;
use think\Session;
class Login extends \think\Controller
{
	//显示登陆页面并验证
	public function login(Request $request){
		if($request->isPost()){
			//$re = input('post.username'),助手函数的用法
            $user = $request->post('username');
            $pwd = $request->post('password');
           // $code = $request->post('code');//验证码 
			
			// echo $user.$pwd;
			Session::set('admin','11');
			$this->success('登陆成功','Index/index');
			//再验证用户名和密码调用模型来完成
			/*if(D('admin')->checkUser($username,$password)){
				$this->success('登陆成功','Index/index',1);
			}else{
				$this->error('用户名或密码错误');
			}*/
			return;
		}
		//载入登陆页面
		//echo Session::get('admin');
		return $this->fetch('Login/login');

	}
}
